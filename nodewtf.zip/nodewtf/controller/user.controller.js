const db = require('../db')
const bcrypt = require('bcryptjs');

const saltRounds = 10;

class UserController{
    async createUser(req, res){
        const {login, password} = req.body
        console.log(login, password)
        const newUser = await db.query(`insert into users (login, password) values ($1, $2) returning *`, [login, password])

        res.json(newUser.rows[0])
    }
    async getUsers(req, res){
        const users = await db.query(`select * from users`)
        res.json(users.rows)
    }
    async getOneUser(req, res){
        const id = req.params.id
        const user = await db.query(`select * from users where id = $1`, [id])
        res.json(user.rows[0])
    }
    
    async updateUser(req, res){
        const {id, login, password} = req.body
        const user = await db.query(`update users set login = $1, password = $2 where id = $3 returning *`, [login, password, id])
        res.json(user.rows[0])
    }
    async deleteUser(req, res){
        const id = req.params.id
        const user = await db.query(`delete from users where id = $1`, [id])
        res.json(user.rows[0])
    }

    async registerUser(req, res) {
        const { login, password } = req.body;

        try {

            const existingUser = await db.query('SELECT * FROM users WHERE login = $1', [login]);

            if (existingUser.rows.length > 0) {
                return res.status(400).json({ error: 'Пользователь с таким логином уже существует' });
            }
            const hashedPassword = await bcrypt.hash(password, saltRounds);

            const newUser = await db.query('INSERT INTO users (login, password) VALUES ($1, $2) RETURNING *', [login, hashedPassword]);

            res.status(201).json(newUser.rows[0]);
        } catch (error) {
            console.error('Ошибка при регистрации:', error.message);
            res.status(500).json({ error: 'Внутренняя ошибка сервера' });
        }
    }

    async loginUser(req, res) {
        const { login, password } = req.body;

        try {

            const user = await db.query('SELECT * FROM users WHERE login = $1', [login]);

            if (user.rows.length === 0) {
                return res.status(401).json({ message: 'Неверные учетные данные' });
            }

            const hashedPassword = user.rows[0].password;
            
            const passwordMatch = await bcrypt.compare(password, hashedPassword);

            if (!passwordMatch) {
                return res.status(401).json({ message: 'Неверные учетные данные' });
            }

            res.json({ message: 'Успешная авторизация' });
        } catch (error) {
            console.error('Ошибка при авторизации:', error);
            res.status(500).json({ message: 'Внутренняя ошибка сервера' });
        }
    }

    async OneUserInfo(req, res) {
        try {
            const login = req.query.userLogin;
            const user = await db.query(`
                SELECT name, title, phone_number 
                FROM employees
                JOIN users ON employees.user_id = users.id
                WHERE users.login = $1;
            `, [login]);
    
            if (user.rows.length === 0) {
                return res.status(404).json({ error: "Пользователь не найден" });
            }
    
            res.json(user.rows[0]);
        } catch (error) {
            console.error("Ошибка при запросе пользователя:", error);
            res.status(500).json({ error: "Внутренняя ошибка сервера" });
        }
    }

}

module.exports = new UserController()