const Router = require('express')
const router = new Router()

const userController = require('../controller/user.controller')
const { registerUser } = require('../controller/user.controller')

router.post('/user', userController.createUser)
router.get('/user', userController.getUsers)
router.get('/user/:id', userController.getOneUser)
router.put('/user', userController.updateUser)
router.delete('/user/:id', userController.deleteUser)
router.post('/register', userController.registerUser);
router.post('/login', userController.loginUser);
router.get('/login', userController.OneUserInfo);


module.exports = router